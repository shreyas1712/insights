import { TestBed, inject } from '@angular/core/testing';

import { BatchDetailsService } from './batch-details.service';

describe('BatchDetailsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BatchDetailsService]
    });
  });

  it('should be created', inject([BatchDetailsService], (service: BatchDetailsService) => {
    expect(service).toBeTruthy();
  }));
});
