import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Batch } from '../batch';
import { Router } from '@angular/router';
import { BatchDetailsService } from './batch-details.service';



@Component({
  selector: 'app-admin-workspace',
  templateUrl: './admin-workspace.component.html',
  styleUrls: ['./admin-workspace.component.css']
})
export class AdminWorkspaceComponent implements OnInit {
  list:Batch[];
  errorMessage: any;
  class:string;
  classroomForm:FormGroup
  seatList:any[];
  constructor(private fbb: FormBuilder, private batchDetailsService:BatchDetailsService, 
    private router: Router) { }
  value() {
    this.batchDetailsService.fetch()
      .then(response =>this.list = response
        //alert(this.list)
        //this.router.navigate(['/traineew']);
      )
      .catch(error => {        
        this.errorMessage =error;
        //alert(this.errorMessage)
      })
  }
  submit(){ 
    //this.class=this.classroomForm.value
    
      //alert(this.errorMessage)
    localStorage.setItem("class", JSON.stringify(this.classroomForm.value));
    
    //alert(this.seatList);
    this.router.navigate(['/seat']);
  }
  ngOnInit() {
    this.value();
    
    this.classroomForm = this.fbb.group({
      classroom: ['', [Validators.required]]
    });
  }
  logout(){
    localStorage.clear();
    this.router.navigate(['/loginA'])
  }
}
