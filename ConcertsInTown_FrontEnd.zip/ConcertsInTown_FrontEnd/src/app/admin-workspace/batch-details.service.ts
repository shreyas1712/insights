import { Injectable } from '@angular/core';
import { BookConcertService } from '../book-concert/book-concert.service';
import { Http } from '@angular/http';
import { Batch } from '../batch';
import { AdminLoginService } from '../admin-login/admin-login.service';

import { environment } from '../../environments/environment.prod';

@Injectable()
export class BatchDetailsService {
batchList:Batch[];
adminId:any;
class:string=localStorage.getItem('section');

  constructor(private http: Http) { }
  fetch() :Promise<Batch[]>{
    this.adminId=localStorage.getItem('adminId')
    return this.http.get(environment.path+'/Batch_details/'+this.adminId)
      .toPromise()
      .then(response => <Batch[]>response.json())
      .catch(this.errorHandler);
  }
  seats() :Promise<any[]>{
    
    return this.http.get(environment.path+'/Admin/TraineeSection/'+this.class)
      .toPromise()
      .then(response =><any[]> response.json()
      )
      .catch(this.errorHandler);
    }
  private errorHandler(error:any):Promise<any> {
  console.error("Error occured",error);    
  return Promise.reject(error.message || error);
  }
}
