import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookConcertComponent } from './book-concert/book-concert.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { TraineeWorkspaceComponent } from './trainee-workspace/trainee-workspace.component';
import { AdminWorkspaceComponent } from './admin-workspace/admin-workspace.component';
import { SeatComponent } from './seat/seat.component';
import { AppComponent } from './app.component';
import { AuthGuard } from './auth.guard';
import { RoleGuardService } from './role-guard.service';

const routes: Routes = [
  { path: '', redirectTo: '/', pathMatch: 'full' },
  { path: 'login', component: BookConcertComponent },
  {path:'loginA', component: AdminLoginComponent},
  { path:'traineew', component: TraineeWorkspaceComponent,canActivate: [AuthGuard,RoleGuardService], data: {expectedRole: 'Trainee'}},
  { path:'adminw', component: AdminWorkspaceComponent, canActivate: [AuthGuard,RoleGuardService], data: {expectedRole: 'Admin'}},
  { path:'seat', component: SeatComponent, canActivate: [AuthGuard,RoleGuardService], data: {expectedRole: 'Admin'}}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
