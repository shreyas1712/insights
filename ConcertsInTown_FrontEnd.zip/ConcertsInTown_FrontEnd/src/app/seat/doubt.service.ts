import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.prod';
import { Http } from '@angular/http';

@Injectable()
export class Doubt{
  section:string=localStorage.getItem('section')
 
  constructor(private http: Http) { }
  doubtFetch(seat) :Promise<any[]>{
    
    return this.http.get(environment.path+'/TraineeSeatMapping/'+this.section+'/'+seat)
      .toPromise()
      .then(response =><any[]> response.json()
      )
      .catch(this.errorHandler);
    }
  private errorHandler(error:any):Promise<any> {
  console.error("Error occured",error);    
  return Promise.reject(error.message || error);
  }
  delete(traineeid,request) :Promise<any>{
    
    return this.http.get(environment.path+'/DeleteAdminRequest/'+request+'/'+traineeid)
      .toPromise()
      .then(response => response
      )
      .catch(this.errorHandler);
    }
}
