import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { environment } from '../../environments/environment.prod';

@Injectable()
export class AdminLoginService {
  adminname:any

  constructor(private http: Http) { }

  loginA(data) :Promise<any>{
    
    return this.http.post(environment.path+'/Admin_details2/',data)
      .toPromise()
      .then(response =>{
        //this.adminname=data.adminId
        localStorage.setItem('adminId',data.adminId);
        return response.json()})
      .catch(this.errorHandler);
  }
  private errorHandler(error:any):Promise<any> {
  console.error("Error occured",error);    
  return Promise.reject(error.message || error);
  }

}  /* istanbul ignore next */

