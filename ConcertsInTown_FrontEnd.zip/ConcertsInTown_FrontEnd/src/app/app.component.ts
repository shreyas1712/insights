import { Component } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {


  isLoggedIn:boolean=true;
  isLoggedOut:boolean=false;
  constructor(private router:Router){}
   loginm(){
     this.isLoggedIn=false;
     this.isLoggedOut=true;
   //this.router.navigate(['/login']);
   }
  loginn(){
     this.isLoggedIn=false;
     this.isLoggedOut=true;
    //this.router.navigate(['/loginA']);
   }
  // logout(){
  //   this.isLoggedIn=true;
  //   this.isLoggedOut=false;
  //   localStorage.clear();
  //   //this.router.navigate(['/']);
  // }
 }