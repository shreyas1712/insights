import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { BookConcertService } from '../book-concert/book-concert.service';
import { Course } from '../Course';
import { AdminLoginService } from '../admin-login/admin-login.service';
import { environment } from '../../environments/environment.prod';

@Injectable()
export class CourseDetailsService {
  CourseList:Course[]
  traineeId:any;
  //this.traineeId=localStorage.getItem('traineeId')

  constructor(private http: Http,private obj:BookConcertService) { 
    
  }

  fetch() :Promise<Course[]>{
    this.traineeId=localStorage.getItem('traineeId')
    return this.http.get(environment.path+'/Course_detail2/'+this.traineeId)
      .toPromise()
      .then(response => <Course[]>response.json())
      .catch(this.errorHandler);
  }
  private errorHandler(error:any):Promise<any> {
  console.error("Error occured",error);    
  return Promise.reject(error.message || error);
  }
}
