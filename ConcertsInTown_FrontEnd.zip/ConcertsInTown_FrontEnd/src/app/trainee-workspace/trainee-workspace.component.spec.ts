import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TraineeWorkspaceComponent } from './trainee-workspace.component';

describe('TraineeWorkspaceComponent', () => {
  let component: TraineeWorkspaceComponent;
  let fixture: ComponentFixture<TraineeWorkspaceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TraineeWorkspaceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TraineeWorkspaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
