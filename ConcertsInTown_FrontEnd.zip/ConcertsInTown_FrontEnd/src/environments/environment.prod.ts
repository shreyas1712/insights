export const environment = {
  production: true,
  path:'http://localhost:8767/Insights/LoginAPI'
};
