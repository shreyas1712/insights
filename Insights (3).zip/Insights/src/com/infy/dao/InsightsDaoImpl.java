package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;





import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.AdminEntity;
import com.infy.entity.BatchEntity;
import com.infy.entity.CourseEntity;
import com.infy.entity.TraineeEntity;
import com.infy.model.Admin;
import com.infy.model.Batch;
import com.infy.model.Course;
import com.infy.model.Trainee;

@Repository("insightsDao")
public class InsightsDaoImpl implements InsightsDAO {
	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public Trainee getTraineeLoginByLoginName(String userName) throws Exception {
		Trainee trainee = null;
		Session session = sessionFactory.getCurrentSession();
		
		TraineeEntity traineeEntity = session.get(TraineeEntity.class,userName);
		
		if (traineeEntity != null) {
			trainee = new Trainee();
			trainee.setId(traineeEntity.getId());
			trainee.setName(traineeEntity.getName());
			trainee.setPassword(traineeEntity.getPassword());
		}

		return trainee;
	}
	
	@Override
	public Admin getAdminLoginByLoginName(String userName) throws Exception {
		Admin admin = null;
		Session session = sessionFactory.getCurrentSession();
		AdminEntity adminEntity = session.get(AdminEntity.class,userName);
		
		if (adminEntity != null) {
			admin = new Admin();
			admin.setId(adminEntity.getId());
			admin.setName(adminEntity.getName());
			admin.setPassword(adminEntity.getPassword());
		}

		return admin;
	}
	
	@Override
	public Trainee getTraineeCourseDetails(String username) throws Exception {
	    Session session = sessionFactory.getCurrentSession();
		Trainee trainee = null;
		List<Course> list = new ArrayList<>();
		TraineeEntity te =  session.get(TraineeEntity.class,username);
		System.out.println(te.getUserName());
		if (te != null) {
			trainee = new Trainee();
			trainee.setId(te.getId());
			trainee.setName(te.getName());
			trainee.setUserName(te.getUserName());
			System.out.println(trainee.getUserName());
			trainee.setPassword(te.getPassword());
			trainee.setSeatNumber(te.getSeatNumber());
			trainee.setBatch(te.getBatch_id());
			
			
			if (te.getCourses() != null) {
				for (CourseEntity ce : te.getCourses()) {
					Course course = new Course();
					course.setCourse_id(ce.getCourse_id());
					course.setCourse_name(ce.getCourse_name());
					list.add(course);
				}
				trainee.setCourses(list);
			}
		}
		System.out.println(trainee.getUserName());
		return trainee;
	}
	
	@Override
	public Admin getAdminBatchDetails(String username) {
		Session session = sessionFactory.getCurrentSession();
		Admin admin = null;
		List<Batch> batchList = new ArrayList<>();
		AdminEntity ae =  session.get(AdminEntity.class,username);		
		if (ae != null) {
			admin = new Admin();
			admin.setId(ae.getId());
			admin.setName(ae.getName());
			admin.setUserName(ae.getUsername());
			admin.setPassword(ae.getPassword());
			if(ae.getBatches() != null)
			{		
					for (BatchEntity be : ae.getBatches()) {
						Batch batch = new Batch();
						batch.setBatch_id(be.getBatch_id());
						batch.setBatchname(be.getBatchname());
						batchList.add(batch);
					}
					admin.setBatches(batchList);
				}
			}
			return admin;
				
	}
	
	@Override
    public Integer getTraineeUsername(String batch,Integer SeatNumber) throws Exception {
		Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
        CriteriaQuery<TraineeEntity> criteriaQuery = criteriaBuilder.createQuery(TraineeEntity.class);
        Root<TraineeEntity> root = criteriaQuery.from(TraineeEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(criteriaBuilder.and(
                criteriaBuilder.equal(root.get("SeatNumber"), SeatNumber)),
                criteriaBuilder.equal(root.get("batch_id"), batch));
        Query query = session.createQuery(criteriaQuery);
        TraineeEntity traineeEntity = (TraineeEntity) query.getSingleResult();
        Trainee trainee=new Trainee();
        trainee.setId(traineeEntity.getId());
        return trainee.getId();
}
	
	
	
}

