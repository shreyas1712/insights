Drop table JEE_Batch cascade constraints;
Drop table Trainee_detail2 cascade constraints;
Drop table Admin_details2 cascade constraints;
Drop table Course_details_Java cascade constraints;
Drop table traineeCourse_Link cascade constraints;
Drop table adminBatch_Link cascade constraints;


CREATE TABLE JEE_Batch (
batch_id VARCHAR2(10) PRIMARY KEY,
batchname VARCHAR2(30)
);


CREATE TABLE Trainee_detail2(
    Id   NUMBER NOT NULL,
    Trainee_name VARCHAR2(20) NOT NULL,
    Username VARCHAR2(10) NOT NULL,
    Password Varchar2(10) NOT NULL,
    SeatNumber Number(3) NOT NULL, 
    batch_id VARCHAR2(10) NOT NULL ,
    
    CONSTRAINT pk_Tr2 PRIMARY KEY(Username)
    
 );


CREATE TABLE Admin_details2(
    Id   NUMBER,
    Admin_name VARCHAR2(20) NOT NULL,
    Username VARCHAR2(10) NOT NULL,
    Password Varchar2(10) NOT NULL,
    
    CONSTRAINT pk_Ad2 PRIMARY KEY(Username)
);


CREATE TABLE Course_details_Java(
    Course_id   NUMBER,
    Course_name VARCHAR2(70) NOT NULL,
    
    CONSTRAINT pk_Cr_id PRIMARY KEY(Course_id)
);
 

CREATE TABLE traineeCourse_Link (
   T_Username VARCHAR(7) REFERENCES Trainee_detail2(Username),
   courseId NUMBER(4) REFERENCES Course_details_Java(Course_id),
   PRIMARY KEY (T_Username, courseId)
);


CREATE TABLE adminBatch_Link (
   A_Username VARCHAR2(10),
   BatchId VARCHAR2(10)
);



INSERT INTO JEE_Batch VALUES ('SR3','JEE_Batch_JAN:17_Sec:A');
INSERT INTO JEE_Batch VALUES ('TL2','JEE_Batch_JAN:17_Sec:B');
INSERT INTO JEE_Batch VALUES ('SR2','JEE_Batch_JAN:28_Sec:A');
INSERT INTO JEE_Batch VALUES ('TL1','JEE_Batch_JAN:28_Sec:B');


INSERT INTO Trainee_detail2 VALUES (563187,'Aman','T563187','@aman100',1,'SR3');
INSERT INTO Trainee_detail2 VALUES (563188,'Vijay','T563188','@vijay101',12,'SR3');
INSERT INTO Trainee_detail2 VALUES (563182,'Rohan','T563182','@rohan102',4,'SR3');
INSERT INTO Trainee_detail2 VALUES (563181,'Neha','T563181','@neha103',11,'SR3');
INSERT INTO Trainee_detail2 VALUES (563183,'Rahul','T563183','@rahul104',5,'SR3');
INSERT INTO Trainee_detail2 VALUES (563184,'Arya','T563184','@arya105',10,'SR3');
INSERT INTO Trainee_detail2 VALUES (563185,'Jon','T563185','@jon106',3,'SR3');
INSERT INTO Trainee_detail2 VALUES (563186,'Sansa','T563186','@sansa107',6,'SR3');
INSERT INTO Trainee_detail2 VALUES (563189,'Akash','T563189','@akash108',9,'SR3');
INSERT INTO Trainee_detail2 VALUES (563190,'Noble','T563190','@noble09',2,'SR3');
INSERT INTO Trainee_detail2 VALUES (563191,'Tarun','T563191','@tarun110',1,'TL2');
INSERT INTO Trainee_detail2 VALUES (563192,'Shashi','T563192','@shashi100',3,'TL2');
INSERT INTO Trainee_detail2 VALUES (563193,'Karan','T563193','@karan101',15,'SR3');
INSERT INTO Trainee_detail2 VALUES (563194,'Hameer','T563194','@hameer102',8,'SR3');
INSERT INTO Trainee_detail2 VALUES (563195,'Ashu','T563195','@ashu103',18,'SR3');
INSERT INTO Trainee_detail2 VALUES (563196,'Naveen','T563196','@naveen104',12,'TL2');
INSERT INTO Trainee_detail2 VALUES (563197,'Uday','T563197','@uday105',14,'TL2');
INSERT INTO Trainee_detail2 VALUES (563198,'Shreya','T563198','@shreya106',16,'SR3');
INSERT INTO Trainee_detail2 VALUES (563199,'Udit','T563199','@udit107',13,'SR3');
INSERT INTO Trainee_detail2 VALUES (563200,'Raghav','T563200','@raghav108',9,'TL2');
INSERT INTO Trainee_detail2 VALUES (563201,'Arpit','T563201','@arpit109',4,'TL2');
INSERT INTO Trainee_detail2 VALUES (563202,'Adrika','T563202','@adrika110',5,'TL2');
INSERT INTO Trainee_detail2 VALUES (563203,'Mayank','T563203','@mayank100',15,'TL2');
INSERT INTO Trainee_detail2 VALUES (563204,'Heroo','T563204','@heroo101',7,'TL2');
INSERT INTO Trainee_detail2 VALUES (563205,'Astha','T563205','@astha102',8,'TL2');
INSERT INTO Trainee_detail2 VALUES (563206,'Aki','T563206','@aki103',10,'TL2');
INSERT INTO Trainee_detail2 VALUES (563207,'Vats','T563207','@vats104',11,'TL2');
INSERT INTO Trainee_detail2 VALUES (563208,'Lavan','T563208','@lavan105',13,'TL2');
INSERT INTO Trainee_detail2 VALUES (563209,'Simran','T563209','@simran106',16,'TL2');
INSERT INTO Trainee_detail2 VALUES (563210,'Kajal','T563210','@kajal107',17,'TL2');
INSERT INTO Trainee_detail2 VALUES (563211,'Ayushi','T563211','@ayushi107',7,'SR3');
INSERT INTO Trainee_detail2 VALUES (563212,'Ayush','T563212','@ayush107',14,'SR3');
INSERT INTO Trainee_detail2 VALUES (563213,'Anand','T563213','@anand107',17,'SR3');
INSERT INTO Trainee_detail2 VALUES (563214,'Alok','T563214','@alok107',18,'TL2');
INSERT INTO Trainee_detail2 VALUES (563215,'Amit','T563215','@amit107',19,'SR3');
INSERT INTO Trainee_detail2 VALUES (563216,'Rashmi','T563216','@rashmi107',20,'SR3');
INSERT INTO Trainee_detail2 VALUES (563217,'Azhar','T563217','@azhar107',2,'TL2');
INSERT INTO Trainee_detail2 VALUES (563218,'Sonali','T563218','@sonali107',6,'TL2');
INSERT INTO Trainee_detail2 VALUES (563219,'Shubh','T563219','@shubh107',19,'TL2');
INSERT INTO Trainee_detail2 VALUES (563220,'Mayur','T563220','@mayur107',20,'TL2');





INSERT INTO Admin_details2 VALUES (463187, 'Suraj','A463187','@suraj100');
INSERT INTO Admin_details2 VALUES (463188, 'Raj','A463188','@raj101');





INSERT INTO Course_details_Java VALUES (1991,'Programming in Java');
INSERT INTO Course_details_Java VALUES (2016,'Bootstrap');
INSERT INTO Course_details_Java VALUES (2089,'Introduction to Hibernate');
INSERT INTO Course_details_Java VALUES (1774,'HTML/CSS');
INSERT INTO Course_details_Java VALUES (1985,'Spring and RESTful API');
INSERT INTO Course_details_Java VALUES (2015,'Developing Persistence Layer using Spring and  Hibernate');


INSERT INTO traineeCourse_Link  VALUES ('T563187',1991);
INSERT INTO traineeCourse_Link  VALUES ('T563187',2016);
INSERT INTO traineeCourse_Link  VALUES ('T563187',2089);
INSERT INTO traineeCourse_Link  VALUES ('T563188',1774);
INSERT INTO traineeCourse_Link  VALUES ('T563188',1991);
INSERT INTO traineeCourse_Link  VALUES ('T563182',2089);
INSERT INTO traineeCourse_Link  VALUES ('T563182',1991);
INSERT INTO traineeCourse_Link  VALUES ('T563182',1774);
INSERT INTO traineeCourse_Link  VALUES ('T563181',1774);
INSERT INTO traineeCourse_Link  VALUES ('T563181',2089);
INSERT INTO traineeCourse_Link  VALUES ('T563183',1985);
INSERT INTO traineeCourse_Link  VALUES ('T563183',2015);
INSERT INTO traineeCourse_Link  VALUES ('T563183',1774);
INSERT INTO traineeCourse_Link  VALUES ('T563188',2089);
INSERT INTO traineeCourse_Link  VALUES ('T563181',2015);
INSERT INTO traineeCourse_Link  VALUES ('T563184',2015);
INSERT INTO traineeCourse_Link  VALUES ('T563184',1985);
INSERT INTO traineeCourse_Link  VALUES ('T563184',2016);
INSERT INTO traineeCourse_Link  VALUES ('T563191',2015);
INSERT INTO traineeCourse_Link  VALUES ('T563191',1985);
INSERT INTO traineeCourse_Link  VALUES ('T563191',2016);
INSERT INTO traineeCourse_Link  VALUES ('T563192',2015);
INSERT INTO traineeCourse_Link  VALUES ('T563192',1985);
INSERT INTO traineeCourse_Link  VALUES ('T563197',2016);




INSERT INTO adminBatch_Link  VALUES ('A463187','TL2');
INSERT INTO adminBatch_Link  VALUES ('A463188','SR3');






Commit;

SELECT * from Trainee_detail2 ;
SELECT * from Admin_details2 ;
select * from Course_details_Java;
SELECT * from traineeCourse_Link  ;
select * from JEE_Batch;
select * from adminBatch_Link;



--select * from userlogin;
--select table_name from user_tables order by table_name;
--drop table CABBOOKING cascade constraints;

