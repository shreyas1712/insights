package com.infy.entity;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Course_details_Java")
public class CourseEntity {
	@Id
	private Integer Course_id;
	private String Course_name;
	
	public Integer getCourse_id() {
		return Course_id;
	}
	public void setCourse_id(Integer course_id) {
		Course_id = course_id;
	}
	public String getCourse_name() {
		return Course_name;
	}
	public void setCourse_name(String course_name) {
		Course_name = course_name;
	}
	
	
	

}
