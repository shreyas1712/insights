package com.infy.dataProcessed;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class RequestTraineesUpdated {
	Integer employeeID;
	String name, request, section, seatNumber;
    final static String filename = "C:/Users/hameer.TRN.ITLINFOSYS/Documents/DataInTake.xls" ;
    final static String deleteFileName = "C:/Users/hameer.TRN.ITLINFOSYS/Documents/DataToClear.xls" ;
	
	static{
		if(!new File(filename).exists())
			try{
	            HSSFWorkbook workbook = new HSSFWorkbook();
	            HSSFSheet sheet = workbook.createSheet("FirstSheet");  
	
	            HSSFRow rowhead = sheet.createRow((int)0);
	            rowhead.createCell(0).setCellValue("EmployeeID");
	            rowhead.createCell(1).setCellValue("Name");
        		rowhead.createCell(2).setCellValue("Request");
        		rowhead.createCell(3).setCellValue("Available");
	            rowhead.createCell(4).setCellValue("seatNumber");
        		rowhead.createCell(5).setCellValue("section");
	            
	            
	
	            
	            FileOutputStream fileOut = new FileOutputStream(filename);
	            workbook.write(fileOut);
	            fileOut.close();
	            workbook.close();
	            //System.out.println("Excel file Working.");

	        } catch ( Exception ex ) {
	            System.out.println(ex);
	        }
		if(!new File(deleteFileName).exists())
			try{
	            HSSFWorkbook workbook = new HSSFWorkbook();
	            HSSFSheet sheet = workbook.createSheet("FirstSheet");  
	
	            HSSFRow rowhead = sheet.createRow((int)0);
	            rowhead.createCell(0).setCellValue("EmployeeID");
	            rowhead.createCell(1).setCellValue("Name");
        		rowhead.createCell(2).setCellValue("Request");
	            rowhead.createCell(3).setCellValue("seatNumber");
        		rowhead.createCell(4).setCellValue("section");
	            
	            FileOutputStream fileOut = new FileOutputStream(deleteFileName);
	            workbook.write(fileOut);
	            fileOut.close();
	            workbook.close();
	            //System.out.println("Excel file Working.");

	        } catch ( Exception ex ) {
	            System.out.println(ex);
	        }
	}
	
	public RequestTraineesUpdated(Integer employeeID, String name, String request, String seatNumber, String section){
		this.employeeID = employeeID;
		this.name = name;
		this.request = request;
		this.seatNumber = seatNumber;
		this.section = section;
	}
	
	
    

}
