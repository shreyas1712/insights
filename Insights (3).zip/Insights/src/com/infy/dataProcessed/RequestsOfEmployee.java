package com.infy.dataProcessed;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class RequestsOfEmployee {
	public static List<String> requestsOfEmployee(Integer employeeId){
		List<String> requestOfTrainee = new ArrayList<>();
		Integer traineeId = 0;
		String traineeName = null;
		try {
            FileInputStream myxls = new FileInputStream(InsertFileCreation.pathname + "/" + employeeId.toString() + ".xlsx");
            XSSFWorkbook workbook = new XSSFWorkbook(myxls);
            XSSFSheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
    	    rowIterator.next();
    	    while (rowIterator.hasNext()){
                Iterator<Cell> cellIterator = rowIterator.next().cellIterator();
                traineeId = (int)cellIterator.next().getNumericCellValue();
                traineeName = cellIterator.next().getStringCellValue();
                requestOfTrainee.add(cellIterator.next().getStringCellValue());
    	    }
    	    workbook.close();
		}catch(Exception ex){
			ex.printStackTrace();
		}
		requestOfTrainee.add(0,traineeId.toString());
		requestOfTrainee.add(1,traineeName);
		return requestOfTrainee;
	}
	

}
