package com.infy.dataProcessed;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;

public class DeleteFileCreation {
    public final static String deleteFileName = "C:/Users/hameer.TRN.ITLINFOSYS/Documents/DataToClear.xls" ;
	public static void deleteRequestList(List<RequestTrainees> rt){

    	try {
            FileInputStream myxls = new FileInputStream(deleteFileName);
            HSSFWorkbook workbook = new HSSFWorkbook(myxls);
            HSSFSheet sheet = workbook.getSheetAt(0); 
            Integer lastRow = sheet.getLastRowNum();
            
            for(RequestTrainees newRequest: rt){
	            HSSFRow row = sheet.createRow((int)++lastRow);
	            row.createCell(0).setCellValue(newRequest.employeeID);
	            row.createCell(1).setCellValue(newRequest.name);
	            row.createCell(2).setCellValue(newRequest.request);
            }
            
            FileOutputStream fileOut = new FileOutputStream(deleteFileName);
            workbook.write(fileOut);
            fileOut.close();
            workbook.close();
        } catch ( Exception ex ) {
            System.out.println(ex);
        }
    }
	
	//Other Utility Fuction
	

    
    public static void deleteRow(HSSFSheet sheet, int rowIndex) throws Exception{
    	int lastRowNum=sheet.getLastRowNum();
        if(rowIndex>=0&&rowIndex<lastRowNum){
            sheet.shiftRows(rowIndex+1,lastRowNum, -1);
        }
        if(rowIndex==lastRowNum){
            HSSFRow removingRow=sheet.getRow(rowIndex);
            if(removingRow!=null){
                sheet.removeRow(removingRow);
            }
        }
    }
    
    public static void deleteRequest(HSSFSheet sheet, RequestTrainees trainee) throws Exception{
            
	        Iterator<Row> rowIterator = sheet.iterator();
	        rowIterator.next();
	        while (rowIterator.hasNext()){
	        	Row row = rowIterator.next();
	            if(row.getCell(2).getStringCellValue().trim().equalsIgnoreCase(trainee.request)){
	            	deleteRow(sheet, row.getRowNum());
	            }
	        }
	        
    }
    
}
