//package com.infy.api;
//
//import org.springframework.core.env.Environment;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.infy.model.Admin;
//import com.infy.service.InsightsService;
//import com.infy.utility.ContextFactory;
//
//@RestController
//@CrossOrigin
//@RequestMapping(value="AdminBatchAPI")
//
//public class AdminBatchAPI {
//
//	@RequestMapping(method=RequestMethod.GET, value="/Admin_details2/{username}")
//	
//	public ResponseEntity<Admin> getAdminBatchDetails(@PathVariable String username  ){
//		
//		Environment environment = ContextFactory.getContext().getEnvironment();
//		InsightsService service = ContextFactory.getContext().getBean(InsightsService.class);
//			
//		ResponseEntity<Admin> responseEntity;
//		try {
//			Admin admin = service.getAdminBatchDetails(username);
//			responseEntity = new ResponseEntity<Admin>(admin,HttpStatus.OK);
//
//		}
//		catch(Exception exception) {				
//			String errorMessage = environment.getProperty(exception.getMessage());
//			Admin admin = new Admin();
//			admin.setMessage(errorMessage);
//			responseEntity = new ResponseEntity<Admin>(admin,HttpStatus.BAD_REQUEST);
//		}
//
//		return responseEntity;
//			
//	}		
//
//
//}
