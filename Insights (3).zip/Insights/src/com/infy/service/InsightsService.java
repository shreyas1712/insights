package com.infy.service;

import com.infy.model.Admin;
import com.infy.model.Trainee;



public interface InsightsService {
	public Trainee getTraineeLoginByLoginName(String username, String password )throws Exception ;
	public Admin getAdminLoginByLoginName(String username, String password)throws Exception ;
	public Trainee getTraineeCourseDetails(String username) throws Exception;
	public Admin getAdminBatchDetails(String username) throws Exception;
	public String getSeatBatch(String userName) throws Exception;
    public Integer getTraineeUsername(String section,Integer SeatNumber) throws Exception;
}
