package com.infy.service;

//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.util.HashSet;
//import java.util.Iterator;
//import java.util.List;
//
//import org.apache.poi.hssf.usermodel.HSSFRow;
//import org.apache.poi.hssf.usermodel.HSSFSheet;
//import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import org.apache.poi.ss.usermodel.Cell;
//import org.apache.poi.ss.usermodel.Row;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.InsightsDaoImpl;
import com.infy.model.Admin;
import com.infy.model.Trainee;

//import com.infy.validation.Validator;

@Service("insightsService")
@Transactional(readOnly = true)
public class InsightsServiceImpl implements InsightsService{
		@Autowired
		private InsightsDaoImpl insightsDAO;
		
		@Override
		public Trainee getTraineeLoginByLoginName(String username, String password)throws Exception {
//			 Validator validate = new Validator();
//			 
//			 validate.TraineeValidate(trainee);
			// String username = trainee.getUserName();
			 Trainee traineeLoginDao = insightsDAO.getTraineeLoginByLoginName(username);
			 if(traineeLoginDao == null){
				throw new Exception("Service.NO_RECORDS");
				}
					
			else{
				if(!password.equals(traineeLoginDao.getPassword()))
						throw new Exception("Service.INVALID_PASSWORD");
				}
					
			return traineeLoginDao;	
				
		}
		
		@Override
		public Admin getAdminLoginByLoginName(String username, String password)throws Exception {
			//Validator validate = new Validator();
			//validate.AdminValidate(admin);
			//String username = admin.getUserName();
			Admin adminLoginDao = insightsDAO.getAdminLoginByLoginName(username);
			
			if(adminLoginDao == null){
				throw new Exception("Service.NO_RECORDS");
				
			}
			
			else{
				if(!password.equals(adminLoginDao.getPassword()))
					throw new Exception("Service.INVALID_PASSWORD");
			}
			
			return adminLoginDao;	

	}
		@Override
		public Trainee getTraineeCourseDetails(String username) throws Exception {
			Trainee trainee = null;
			trainee = insightsDAO.getTraineeCourseDetails(username);
			if (trainee == null) {
				throw new Exception("Service.TRAINEE_NOT_FOUND");
			}
			return trainee;
		}
		
		@Override
		public Admin getAdminBatchDetails(String username) throws Exception{
			
			Admin admin = null;
			admin = insightsDAO.getAdminBatchDetails(username);
			if (admin == null) {
				throw new Exception("Service.ADMIN_NOT_FOUND");
			}
			return admin;
		}
		
		@Override
		public String getSeatBatch(String username) throws Exception
		{
			String seatBatch = null;
			Trainee trainee = null;
			trainee = insightsDAO.getTraineeCourseDetails(username);
			seatBatch = trainee.getSeatNumber()+"-"+trainee.getBatch();
			
			return seatBatch ;
			
		}
		
		@Override
	    public Integer getTraineeUsername(String section,Integer SeatNumber) throws Exception {
			Integer traineeId=null;
			traineeId = insightsDAO.getTraineeUsername(section,SeatNumber);
			
			return traineeId;
			
		}
		
}
		
