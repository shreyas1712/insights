package com.infy.validation;

import com.infy.model.Admin;
import com.infy.model.Trainee;

public class Validator {
	public void TraineeValidate(Trainee trainee) throws Exception {

		try{
			if (!isValidUserName(trainee.getUserName())) {
				throw new Exception("Validator.INVALID_USERNAME");
			}
			if(!isValidPassword(trainee.getPassword())){
				throw new Exception("Validator.INVALID_PASSWORD");
			}
		}
		
		catch(Exception e)
		{
			throw e;
		}
	}
	
	public void AdminValidate(Admin admin) throws Exception {

		try{
			if (!isValidUserName(admin.getUserName())) {
				throw new Exception("Validator.INVALID_USERNAME");
			}
			if(!isValidPassword(admin.getPassword())){
				throw new Exception("Validator.INVALID_PASSWORD");
			}
		}
		
		catch(Exception e)
		{
			throw e;
		}
	}
	
	public Boolean isValidUserName(String userName) {
		String regex = "[T|A][0-9]{6}";
		if(userName.matches(regex))
			return true;		
		
		return false;
		
	}
	
	public Boolean isValidPassword(String password) {
		String regex = "@[A-Za-z0-9]{4,}";
		if(password.matches(regex))
			return true;		
		
		return false;		
	}
}
	
